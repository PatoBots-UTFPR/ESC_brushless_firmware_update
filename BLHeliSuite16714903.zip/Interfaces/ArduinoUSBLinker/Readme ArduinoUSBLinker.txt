BLHeliSuite uses ArduinoUSBLinker annd provides a copy of the ino file in it's distribution.
For further info about ArduinoUSBLinker see https://github.com/c---/ArduinoUSBLinker

atmega32u4 boards are not supported.
